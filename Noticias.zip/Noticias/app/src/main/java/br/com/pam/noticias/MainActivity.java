package br.com.pam.noticias;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btProximo;  //

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btProximo = findViewById(R.id.btProximo);
    }

    public void Proximo(View view) {

        Intent intent = new Intent(MainActivity.this, Tela2.class);  //Abre uma Pagina
        startActivity(intent); // Iniciar a Atividade ou Carregar a tela
    }
}