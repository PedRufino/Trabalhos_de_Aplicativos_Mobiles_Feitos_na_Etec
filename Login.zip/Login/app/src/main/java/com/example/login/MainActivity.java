package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Application;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import java.io.Closeable;

public class MainActivity extends AppCompatActivity {

    ImageView imgAndroid, imgVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgAndroid = (ImageView)findViewById(R.id.imgAndroid);
        imgVoltar = (ImageView)findViewById(R.id.imgVoltar);

        imgAndroid.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                Intent web = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.android.com/intl/pt-BR_br/"));
                startActivity(web);

            }
        });

        imgVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();

            }
        });
    }
}