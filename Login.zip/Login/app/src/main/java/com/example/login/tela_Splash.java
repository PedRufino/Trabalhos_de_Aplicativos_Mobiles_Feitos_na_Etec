package com.example.login;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class tela_Splash extends AppCompatActivity {

    private static  int TEMPO_SPLASH = 5000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_splash);

        barra();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent i = new Intent(tela_Splash.this, Login.class);
                startActivity(i);
                finish();
            }
        },TEMPO_SPLASH);
    }

    public void barra(){
        ProgressDialog barradeprogresso = new ProgressDialog(this);
            barradeprogresso.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            barradeprogresso.setTitle("Carregando, aguarde...");
            barradeprogresso.setMessage("Carregando a Tela de Login...");
            barradeprogresso.show();
    }
}