package com.example.login;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    EditText edNome, edSenha;
    Button logar, logout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        edNome = (EditText) findViewById(R.id.edNome);
        edSenha = (EditText) findViewById(R.id.edSenha);
        logar = (Button) findViewById(R.id.logar);
        logout = (Button) findViewById(R.id.logout);

        logar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                //

                if (edNome.getText().length()==0 || edSenha.getText().length()==0){
                    Toast.makeText(getApplication(),"Favor preencher o Login e a Senha", Toast.LENGTH_LONG).show();

                        Toast.makeText(getApplication(),"Dados não validos!!!", Toast.LENGTH_LONG).show();
                }else{
                    edNome.setText(" ");
                    edSenha.setText(" ");

                    Toast.makeText(getApplication(), "Acesso permitido " + edNome.getText().toString()+ "!",
                            Toast.LENGTH_LONG).show();

                        //Acessar a tela seguinte
                    Intent tela_dois = new Intent(Login.this, MainActivity.class);
                    startActivity(tela_dois);
                }

            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0){
                //Todo Auto-generated method stub
                msgsair();
            }
        });

    }
    public void msgsair(){

        AlertDialog.Builder msg = new AlertDialog.Builder(this);
        msg.setMessage("Deseja realmente sair da Aplicação ?");
        msg.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int arg1) {
                // Todo Auto-generated method stub
                finish();
            }
        });
        msg.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface arg0, int arg1) {
                // Todo Auto-generated method stub

            }
        });

        msg.setTitle("Deseja Sair?");
        msg.show();

        }

    }